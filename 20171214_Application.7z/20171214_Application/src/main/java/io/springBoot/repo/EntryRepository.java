package io.springBoot.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import io.springBoot.pojo.Entry;


public interface EntryRepository extends JpaRepository<Entry, Long> {
	
	
	public List<Entry> findAll();

}
