package io.springBoot.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.springBoot.pojo.Entry;
import io.springBoot.repo.EntryRepository;

@Service
@Transactional
public class EntryService {
	
	@Autowired
	private EntryRepository entryRepository;
	
	
	
	public List<Entry> findAll() {
		return entryRepository.findAll();
	}
	
	public void save(Entry entry) {
		entryRepository.save(entry);
	}
	
	public long parseDateToMili(String dateString) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		Date date = null;
		try {
			date = sdf.parse(dateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long millis = date.getTime();
		return millis;
	}
	
  	public long getDateDiff(String clockOut, String clockIn) throws ParseException {
 
  	  	DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.ENGLISH);
  	  	Date date = format.parse(clockOut);
  	  	Date date2 = format.parse(clockIn);

  		long diff = date.getTime() - date2.getTime();
  		long diffHours = diff / (60 * 60 * 1000);
  		return diffHours;
	}
  	
  	
  	public long getTotal(List<Entry> list ) {
  		long sum = 0;
  		for(Entry en: list) {
  			sum += en.getDiff();	
  		}
  		return sum;
  	}
  	


  	
  	
  	
  
  	
}
