package io.springBoot.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="pontaj")
public class Entry {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	
	long clockIn;
	long clockOut;
	long diff;

	public Entry() {};
	
	public Entry(long clockIn, long clockOut,long diff) {;
		this.clockIn = clockIn;
		this.clockOut = clockOut;
		this.diff = diff;
	}
	
	
	public long getId() {
		return id;
	}
	public long getClockIn() {
		return clockIn;
	}
	public long getClockOut() {
		return clockOut;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setClockIn(long clockIn) {
		this.clockIn = clockIn;
	}
	public void setClockOut(long clockOut) {
		this.clockOut = clockOut;
	}

	public long getDiff() {
		return diff;
	}

	public void setDiff(long diff) {
		this.diff = diff;
	}
	
}
