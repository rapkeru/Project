package io.springBoot.controllers;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import io.springBoot.pojo.Entry;
import io.springBoot.services.EntryService;

@Controller
public class EntryController {

	
	@Autowired
	private EntryService entryService;
	
	
	@RequestMapping( value = "/main", method =  RequestMethod.GET )
	public String viewEntry(  @RequestParam(value="name", required=false) String name,
			Model model) {
		model.addAttribute("entries", entryService.findAll());
		System.out.println("sunt in viewEntry::::" + name);
		return "main";
	}
	
	@RequestMapping( value = "/main", method =  RequestMethod.POST )
	public String saveEntry(  //@RequestParam(value="name", required=false) String name,
			Model model) {
		model.addAttribute("entries", entryService.findAll());
		System.out.println("sunt in saveEntry::::" + "");
		return "main";
	}
	
	@RequestMapping( value = "/popup", method =  RequestMethod.GET )
	public String testEntry(    @RequestParam(value="clockIn", required=false) String clockIn,
								@RequestParam(value="clockOut", required=false) String clockOut,
							    Model model) {
		model.addAttribute("clockIn", clockIn);
		model.addAttribute("clockOut", clockOut);
		System.out.println("sunt in testEntry::::" + clockIn);
		System.out.println("sunt in testEntry::::" + clockOut);
		return "popup";
	}
	
	@RequestMapping( value = "/popup", method =  RequestMethod.POST )
	public String addEntry( @RequestParam(value="clockIn", required=false) String clockIn,
							@RequestParam(value="clockOut", required=false) String clockOut,
							Model model) throws ParseException {
		model.addAttribute("entries", entryService.findAll());
		model.addAttribute("clockIn", clockIn);
		model.addAttribute("clockOut", clockOut);
		model.addAttribute("diff", entryService.getDateDiff(clockOut,clockIn));
		model.addAttribute("total", entryService.getTotal(entryService.findAll()));
		System.out.println("difference is ::::" + entryService.getDateDiff(clockOut,clockIn));
		System.out.println("sunt in addEntry::::" + clockIn);
		System.out.println("sunt in addEntry::::" + clockOut);
		System.out.println("total::::" + entryService.getTotal(entryService.findAll()));
		Entry entry = new Entry(entryService.parseDateToMili(clockIn),entryService.parseDateToMili(clockOut),entryService.getDateDiff(clockOut,clockIn));
		entryService.save(entry);

		return "main";
	}
	
}
